/**
 * StudyMate Ultimate — single-file full-stack study assistant
 * Author: Riddhi Soni | soniriddhi1519@gmail.com
 *
 * Local: npm install && npm start
 * Configure OPENAI_API_KEY and JWT_SECRET in the environment for production.
 *
 * Note: Vercel serverless instances have ephemeral local storage and may be reused
 * unpredictably. SQLite is suitable for local development; use a persistent hosted
 * database for durable multi-instance production deployments.
 */
'use strict';

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-development-secret-before-deploying';
const TOKEN_TTL = '7d';
const VERSION = '1.0.0';

app.disable('x-powered-by');
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Use a file database locally. Set DB_PATH=:memory: to use an in-memory database.
const dbPath = process.env.DB_PATH === ':memory:'
  ? ':memory:'
  : (process.env.DB_PATH || path.join(__dirname, 'studymate.sqlite'));

const db = new sqlite3.Database(dbPath);
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS generations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    topic TEXT NOT NULL,
    result_json TEXT NOT NULL,
    source TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);
});

const dbGet = (sql, params = []) => new Promise((resolve, reject) =>
  db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
const dbRun = (sql, params = []) => new Promise((resolve, reject) =>
  db.run(sql, params, function (err) {
    if (err) reject(err);
    else resolve({ lastID: this.lastID, changes: this.changes });
  }));
const dbAll = (sql, params = []) => new Promise((resolve, reject) =>
  db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email };
}
function signToken(user) {
  return jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}
function optionalUser(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : (req.body && req.body.token);
  if (!token) return null;
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    return { id: Number(payload.sub), email: payload.email };
  } catch (_) {
    return null;
  }
}
function safeParseJSON(value) {
  try { return JSON.parse(value); } catch (_) { return null; }
}

function buildDemoResult(topic) {
    return {
      topic,
      explanation: `${topic} is easier to understand when you break it into its core idea, how it works, and why it matters. Start with the definition, connect each step to the next, then test your understanding with a small example.`,
      analogy: `Think of ${topic} like a well-organized toolbox: each part has a role, and the right combination helps you solve a specific problem.`,
      examples: [
        `Define ${topic} in one sentence using your own words.`,
        `Find a real-world situation where ${topic} is useful.`,
        `Create a small worked example and explain each step aloud.`
      ],
      qa: [
        { question: `What is the central idea behind ${topic}?`, answer: `Identify its definition, purpose, and the key principles that make it work.` },
        { question: `How can I remember ${topic}?`, answer: `Connect the concept to a familiar example, then retrieve it from memory without looking at your notes.` }
      ],
      memoryTrick: `Use the “D-E-A” loop for ${topic}: Define it, Explain it in your own words, Apply it to an example.`,
      source: 'Demo Mode'
    };
}

async function generateWithOpenAI(topic) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return buildDemoResult(topic);


  const systemPrompt = `You are StudyMate Ultimate, a professional study assistant by Riddhi Soni. Explain the user's topic simply, accurately, and helpfully for a student. Return ONLY valid JSON with this schema:
{"explanation":"string","analogy":"string","examples":["string","string","string"],"qa":[{"question":"string","answer":"string"},{"question":"string","answer":"string"}],"memoryTrick":"string"}
Avoid markdown fences. Use clear, concise language.`;
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      temperature: 0.5,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Teach me this topic: ${topic}` }
      ]
    }),
    signal: AbortSignal.timeout(45000)
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new Error(`OpenAI request failed (${response.status}): ${detail.slice(0, 300)}`);
  }
  const payload = await response.json();
  const content = payload.choices && payload.choices[0] && payload.choices[0].message
    ? payload.choices[0].message.content : '';
  const parsed = safeParseJSON(content);
  if (!parsed || typeof parsed.explanation !== 'string') {
    throw new Error('The AI response was not valid study content.');
  }
  return {
    topic,
    explanation: parsed.explanation,
    analogy: typeof parsed.analogy === 'string' ? parsed.analogy : '',
    examples: Array.isArray(parsed.examples) ? parsed.examples.slice(0, 5) : [],
    qa: Array.isArray(parsed.qa) ? parsed.qa.slice(0, 5) : [],
    memoryTrick: typeof parsed.memoryTrick === 'string' ? parsed.memoryTrick : '',
    source: 'Real OpenAI GPT-4o-mini'
  };
}

app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    version: VERSION,
    author: 'Riddhi Soni',
    openai: process.env.OPENAI_API_KEY ? 'Enabled' : 'Disabled'
  });
});

app.post('/api/auth/signup', async (req, res) => {
  try {
    const name = String(req.body?.name || '').trim();
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    if (name.length < 2 || name.length > 80) return res.status(400).json({ error: 'Name must be between 2 and 80 characters.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).json({ error: 'Enter a valid email address.' });
    if (password.length < 6 || password.length > 128) return res.status(400).json({ error: 'Password must be at least 6 characters.' });

    const existing = await dbGet('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) return res.status(409).json({ error: 'An account with this email already exists. Please log in.' });
    const passwordHash = await bcrypt.hash(password, 12);
    const inserted = await dbRun('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [name, email, passwordHash]);
    const user = { id: inserted.lastID, name, email };
    return res.status(201).json({ token: signToken(user), user });
  } catch (err) {
    console.error('Signup error:', err.message);
    return res.status(500).json({ error: 'Could not create your account. Please try again.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });
    const user = await dbGet('SELECT id, name, email, password_hash FROM users WHERE email = ?', [email]);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Email or password is incorrect.' });
    }
    return res.json({ token: signToken(user), user: publicUser(user) });
  } catch (err) {
    console.error('Login error:', err.message);
    return res.status(500).json({ error: 'Could not log in right now. Please try again.' });
  }
});

app.post('/api/generate', async (req, res) => {
  const topic = String(req.body?.topic || '').trim();
  if (!topic || topic.length > 500) return res.status(400).json({ error: 'Enter a topic (up to 500 characters).' });
  const user = optionalUser(req);
  try {
    let result;
    try {
      result = await generateWithOpenAI(topic);
    } catch (err) {
      // If the live provider is unavailable, keep the app usable with a clear source label.
      console.error('AI generation failed:', err.message);
      result = await generateWithOpenAIWithoutKey(topic);
      result.source = 'Demo Mode (AI unavailable)';
    }
    await dbRun(
      'INSERT INTO generations (user_id, topic, result_json, source) VALUES (?, ?, ?, ?)',
      [user ? user.id : null, topic, JSON.stringify(result), result.source]
    );
    res.json({ result });
  } catch (err) {
    console.error('Generation error:', err.message);
    res.status(500).json({ error: 'Could not generate study notes. Please try again.' });
  }
});

// Separate demo generator is used only when a configured provider request fails.
async function generateWithOpenAIWithoutKey(topic) {
  return buildDemoResult(topic);
}

app.get('/api/history', async (req, res) => {
  const user = optionalUser(req);
  try {
    const rows = user
      ? await dbAll('SELECT id, topic, result_json, source, created_at FROM generations WHERE user_id = ? ORDER BY id DESC LIMIT 20', [user.id])
      : await dbAll('SELECT id, topic, result_json, source, created_at FROM generations WHERE user_id IS NULL ORDER BY id DESC LIMIT 20');
    res.json({ history: rows.map(row => ({
      id: row.id,
      topic: row.topic,
      source: row.source,
      createdAt: row.created_at,
      result: safeParseJSON(row.result_json)
    })) });
  } catch (err) {
    console.error('History error:', err.message);
    res.status(500).json({ error: 'Could not load history.' });
  }
});

const FRONTEND_HTML = String.raw`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#070708">
<meta name="description" content="StudyMate Ultimate — a focused AI study companion by Riddhi Soni.">
<title>StudyMate Ultimate — Learn with clarity</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
<style>
:root{color-scheme:dark;--bg:#070708;--panel:rgba(255,255,255,.055);--border:rgba(255,255,255,.1);--muted:#8b8ba0;--text:#f5f3ff;--purple:#7c3aed;--pink:#ec4899;--grad:linear-gradient(110deg,#7c3aed 0%,#a855f7 48%,#ec4899 100%);font-family:Inter,system-ui,sans-serif}
*{box-sizing:border-box}html{min-height:100%;background:var(--bg)}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 50% -15%,rgba(124,58,237,.15),transparent 48%),var(--bg);color:var(--text);font-family:Inter,system-ui,sans-serif;overflow-x:hidden}button,input{font:inherit}button{cursor:pointer}a{color:inherit;text-decoration:none}#scene{position:fixed;inset:0;width:100%;height:100%;z-index:0;pointer-events:none;opacity:.75}.app-shell{position:relative;z-index:1;min-height:100vh}.topbar{height:64px;position:fixed;z-index:10;top:0;left:0;right:0;display:flex;align-items:center;justify-content:space-between;padding:0 5.5%;border-bottom:1px solid rgba(255,255,255,.08);background:rgba(7,7,8,.68);backdrop-filter:blur(24px)}.brand{display:flex;align-items:center;gap:11px;font-family:'Space Grotesk',Inter,sans-serif;font-weight:700;letter-spacing:-.6px}.brand-mark{width:29px;height:29px;border-radius:9px;background:var(--grad);display:grid;place-items:center;box-shadow:0 0 26px rgba(124,58,237,.35)}.brand-mark svg{width:17px;height:17px}.brand small{font:700 9px Inter,sans-serif;letter-spacing:.7px;color:#e9d5ff;background:rgba(124,58,237,.2);border:1px solid rgba(167,139,250,.35);padding:5px 7px;border-radius:6px;margin-left:2px}.top-right{display:flex;align-items:center;gap:12px;color:var(--muted);font-size:12px}.api-badge{display:inline-flex;align-items:center;gap:6px;border:1px solid rgba(167,139,250,.3);border-radius:7px;background:rgba(124,58,237,.17);color:#c4b5fd;padding:7px 9px;font-size:10px;font-weight:800;letter-spacing:.35px}.dot{width:6px;height:6px;border-radius:50%;background:#a78bfa;box-shadow:0 0 9px currentColor}.main{padding:100px 5.5% 60px;max-width:1440px;margin:auto}.auth-page{min-height:calc(100vh - 100px);display:flex;align-items:center;justify-content:center;gap:clamp(40px,8vw,120px);padding:24px 0 60px}.auth-copy{max-width:530px;flex:1}.eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:2px;font-weight:800;color:#c4b5fd;display:flex;align-items:center;gap:9px}.eyebrow:before{content:'';width:22px;height:1px;background:#a78bfa}.auth-copy h1,.hero h1{font-family:'Space Grotesk',Inter,sans-serif;font-size:clamp(42px,5.2vw,66px);line-height:1.04;letter-spacing:-2.8px;margin:20px 0 22px;font-weight:700}.gradient-text{background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}.lead{font-size:15px;line-height:1.85;color:#aaa8bd;max-width:470px}.feature-list{display:grid;gap:17px;margin-top:34px}.feature{display:flex;align-items:flex-start;gap:13px;color:#c9c6d8;font-size:13px;line-height:1.6}.feature-icon{flex:0 0 30px;height:30px;border:1px solid rgba(167,139,250,.22);border-radius:9px;background:rgba(124,58,237,.13);display:grid;place-items:center;color:#c4b5fd;font-size:14px}.feature strong{display:block;color:#f4f0ff;font-size:13px;margin-bottom:2px}.auth-card{width:100%;max-width:400px;flex:0 0 400px;padding:30px;border:1px solid rgba(255,255,255,.12);border-radius:24px;background:rgba(17,16,23,.72);backdrop-filter:blur(40px);box-shadow:0 20px 80px rgba(0,0,0,.45),inset 0 1px rgba(255,255,255,.04)}.card-heading{font:700 25px 'Space Grotesk',sans-serif;letter-spacing:-1px;margin:0 0 8px}.subheading{color:var(--muted);font-size:12px;line-height:1.7;margin:0 0 25px}.tabs{display:grid;grid-template-columns:1fr 1fr;gap:4px;background:rgba(255,255,255,.04);padding:4px;border-radius:10px;margin-bottom:23px}.tab{border:0;background:transparent;color:var(--muted);padding:10px;border-radius:7px;font-size:12px;font-weight:700}.tab.active{background:rgba(255,255,255,.09);color:#fff;box-shadow:0 2px 8px rgba(0,0,0,.2)}.field{display:grid;gap:8px;margin-bottom:15px}.field label{font-size:11px;font-weight:700;color:#c7c4d4}.field input,.search-input{width:100%;color:#fff;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:13px 14px;outline:none;transition:border .2s,box-shadow .2s,background .2s;font-size:13px}.field input::placeholder,.search-input::placeholder{color:#69687b}.field input:focus,.search-input:focus{border-color:#7c3aed;box-shadow:0 0 0 4px rgba(124,58,237,.2);background:rgba(255,255,255,.06)}.primary-btn{border:0;border-radius:10px;padding:13px 16px;background:var(--grad);color:white;font-weight:800;font-size:12px;box-shadow:0 8px 24px rgba(124,58,237,.22);transition:transform .2s,box-shadow .2s;width:100%;margin-top:5px}.primary-btn:hover{transform:translateY(-1px);box-shadow:0 12px 28px rgba(124,58,237,.34)}.primary-btn:disabled{opacity:.65;cursor:wait;transform:none}.auth-error{display:none;border:1px solid rgba(248,113,113,.28);background:rgba(127,29,29,.2);color:#fca5a5;padding:10px;border-radius:9px;font-size:11px;line-height:1.5;margin-bottom:14px}.auth-foot{font-size:10px;color:#737286;text-align:center;margin-top:19px;line-height:1.7}.app-view{display:none}.workspace{display:grid;grid-template-columns:1.2fr .8fr;gap:22px;align-items:start}.hero{padding:28px 0 22px}.hero h1{font-size:clamp(36px,4.2vw,52px);max-width:650px;margin:16px 0}.hero .lead{max-width:580px}.search-panel{position:relative;border:1px solid rgba(255,255,255,.12);background:rgba(22,20,31,.67);backdrop-filter:blur(24px);border-radius:19px;padding:12px;box-shadow:0 20px 60px rgba(0,0,0,.34),inset 0 1px rgba(255,255,255,.04);transition:transform .18s ease,border-color .2s;transform-style:preserve-3d}.search-row{display:flex;gap:10px}.search-input{background:transparent;border:0;box-shadow:none!important;flex:1;min-width:0;padding:14px}.search-input:focus{border:0}.search-btn{width:auto;min-width:126px;margin:0;padding:0 17px}.search-hint{padding:10px 12px 3px;color:#77758b;font-size:10px;display:flex;justify-content:space-between;gap:10px}.topic-pills{display:flex;flex-wrap:wrap;gap:8px;margin-top:17px}.pill{border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.035);color:#b7b3c9;border-radius:100px;padding:8px 12px;font-size:10px;transition:all .2s}.pill:hover{border-color:rgba(167,139,250,.5);color:#e9d5ff;background:rgba(124,58,237,.12)}.section-head{display:flex;align-items:center;justify-content:space-between;margin:26px 0 13px}.section-head h2{font:700 14px 'Space Grotesk',sans-serif;letter-spacing:-.3px;margin:0}.tiny-label{font-size:9px;color:#77758b;letter-spacing:1px;text-transform:uppercase;font-weight:800}.result-stack{display:grid;gap:12px}.glass-card{border:1px solid var(--border);background:rgba(255,255,255,.045);border-radius:17px;padding:19px;backdrop-filter:blur(18px);box-shadow:0 12px 38px rgba(0,0,0,.18)}.result-card{animation:rise .35s ease both}.result-title{font:700 13px 'Space Grotesk',sans-serif;margin:0 0 11px;display:flex;align-items:center;gap:8px}.result-title .mini-icon{width:23px;height:23px;border-radius:7px;display:grid;place-items:center;background:rgba(124,58,237,.18);color:#c4b5fd}.result-card p,.result-card li{font-size:12px;line-height:1.85;color:#b9b6c9}.result-card p{margin:0}.result-card ul{margin:0;padding-left:18px}.result-card li+li{margin-top:5px}.result-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}.right-column{padding-top:40px}.side-card{margin-bottom:13px}.profile-row{display:flex;align-items:center;gap:12px}.avatar{height:40px;width:40px;border-radius:13px;background:var(--grad);display:grid;place-items:center;font:700 15px 'Space Grotesk',sans-serif;box-shadow:0 8px 24px rgba(124,58,237,.22)}.profile-name{font-weight:700;font-size:12px}.profile-email{font-size:10px;color:var(--muted);margin-top:4px}.divider{height:1px;background:rgba(255,255,255,.08);margin:17px 0}.stat-row{display:flex;justify-content:space-between;align-items:center;font-size:11px;color:var(--muted);padding:7px 0}.stat-row strong{color:#e9e5f5;font-size:11px}.history-list{display:grid;gap:8px}.history-item{padding:11px 12px;border:1px solid rgba(255,255,255,.07);border-radius:10px;background:rgba(255,255,255,.025);cursor:pointer}.history-item:hover{border-color:rgba(167,139,250,.3)}.history-item strong{display:block;font-size:11px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.history-item span{display:block;color:#77758b;font-size:9px;margin-top:5px}.empty-state{color:#77758b;font-size:11px;line-height:1.7}.logout-btn{border:1px solid rgba(255,255,255,.12);border-radius:8px;background:rgba(255,255,255,.04);color:#c9c6d8;padding:8px 11px;font-size:10px;font-weight:700}.logout-btn:hover{border-color:rgba(236,72,153,.35);color:#fbcfe8}.footer{border-top:1px solid rgba(255,255,255,.07);margin-top:50px;padding:20px 0;display:flex;justify-content:space-between;gap:15px;color:#69687b;font-size:10px}.loading-line{display:none;align-items:center;gap:9px;color:#c4b5fd;font-size:10px;margin-top:13px}.spinner{width:13px;height:13px;border:2px solid rgba(196,181,253,.25);border-top-color:#c4b5fd;border-radius:50%;animation:spin .7s linear infinite}.toast{display:none;position:fixed;z-index:20;bottom:22px;left:50%;transform:translateX(-50%);border:1px solid rgba(167,139,250,.3);border-radius:10px;background:rgba(20,18,30,.95);backdrop-filter:blur(20px);padding:12px 16px;color:#ddd6fe;font-size:11px;box-shadow:0 12px 40px rgba(0,0,0,.4);max-width:90vw}.hidden{display:none!important}@keyframes spin{to{transform:rotate(360deg)}}@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}@media(max-width:900px){.auth-page{flex-direction:column;align-items:stretch;gap:35px;padding-top:20px}.auth-copy{max-width:650px}.auth-copy h1{font-size:clamp(42px,8vw,60px)}.auth-card{flex:0 1 auto;max-width:500px;align-self:center}.workspace{grid-template-columns:1fr}.right-column{padding-top:0}.main{padding-left:5%;padding-right:5%}.topbar{padding:0 5%}}@media(max-width:560px){.topbar{height:60px}.brand{font-size:13px;gap:7px}.brand small{font-size:8px;padding:4px 5px}.top-right{gap:7px}.top-right .api-badge{font-size:8px;padding:6px}.top-right #topUser{display:none}.main{padding-top:85px}.auth-card{padding:23px;border-radius:20px}.auth-copy h1{letter-spacing:-2px}.search-row{flex-direction:column}.search-btn{min-height:43px;width:100%}.result-grid{grid-template-columns:1fr}.footer{flex-direction:column}.hero h1{letter-spacing:-2px}.hero{padding-top:14px}}@media(prefers-reduced-motion:reduce){*,*:before,*:after{animation-duration:.01ms!important;transition-duration:.01ms!important}}
</style>
</head>
<body>
<canvas id="scene" aria-hidden="true"></canvas>
<div class="app-shell">
<header class="topbar">
  <a class="brand" href="#" aria-label="StudyMate Ultimate home"><span class="brand-mark"><svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 7v10l8 4 8-4V7z"/><path d="m4 7 8 4 8-4M12 11v10"/></svg></span><span>StudyMate <span style="color:#c4b5fd">ULTIMATE</span></span><small>REAL AI</small></a>
  <div class="top-right"><span id="topUser">Your personal study space</span><span id="apiBadge" class="api-badge"><span class="dot"></span> CHECKING API</span><button id="logoutBtn" class="logout-btn hidden">Log out ↗</button></div>
</header>
<main class="main">
<section id="authView" class="auth-page">
  <div class="auth-copy">
    <div class="eyebrow">A clearer way to learn</div>
    <h1>Real AI.<br>Not Demo.<br><span class="gradient-text">Production.</span></h1>
    <p class="lead">Turn complex subjects into clear explanations, memorable analogies, practical examples, and revision-ready notes — all in one focused workspace.</p>
    <div class="feature-list">
      <div class="feature"><span class="feature-icon">✳</span><div><strong>AI-powered explanations</strong>Understand difficult ideas in plain language with OpenAI GPT-4o-mini when configured.</div></div>
      <div class="feature"><span class="feature-icon">⌘</span><div><strong>Learn by connecting ideas</strong>Use analogies, worked examples, Q&amp;A, and memory tricks to reinforce understanding.</div></div>
      <div class="feature"><span class="feature-icon">◈</span><div><strong>Your learning workspace</strong>Keep recent generations together with a responsive, immersive 3D interface.</div></div>
    </div>
  </div>
  <div class="auth-card">
    <div class="tabs"><button class="tab active" id="loginTab">Log in</button><button class="tab" id="signupTab">Create account</button></div>
    <h2 class="card-heading" id="authTitle">Welcome back.</h2><p class="subheading" id="authSubtitle">Sign in to pick up where your curiosity left off.</p>
    <div id="authError" class="auth-error" role="alert"></div>
    <form id="authForm">
      <div class="field hidden" id="nameField"><label for="name">YOUR NAME</label><input id="name" autocomplete="name" placeholder="Riddhi Soni" minlength="2" maxlength="80"></div>
      <div class="field"><label for="email">EMAIL ADDRESS</label><input id="email" type="email" autocomplete="email" value="soniriddhi1519@gmail.com" placeholder="you@example.com" required></div>
      <div class="field"><label for="password">PASSWORD</label><input id="password" type="password" autocomplete="current-password" value="123456" minlength="6" placeholder="At least 6 characters" required></div>
      <button id="authSubmit" class="primary-btn" type="submit">Login via Real API →</button>
    </form>
    <p class="auth-foot">Secure password hashing · JWT session · Built by <strong style="color:#c4b5fd">Riddhi Soni</strong><br>soniriddhi1519@gmail.com</p>
  </div>
</section>

<section id="appView" class="app-view">
  <div class="workspace">
    <div class="left-column">
      <div class="hero">
        <div class="eyebrow">Your personal learning engine</div>
        <h1>Make hard topics<br><span class="gradient-text">feel simple.</span></h1>
        <p class="lead">Ask about anything you’re studying. Get a clear breakdown, a real-world analogy, examples, and a memory trick you can revisit.</p>
      </div>
      <div id="searchPanel" class="search-panel">
        <form id="generateForm" class="search-row"><input id="topicInput" class="search-input" maxlength="500" placeholder="What do you want to understand today?" aria-label="Study topic" required><button id="generateBtn" class="primary-btn search-btn" type="submit">Generate notes ↗</button></form>
        <div class="search-hint"><span>↵ Enter to generate</span><span>Keep it curious. Keep it clear.</span></div>
      </div>
      <div class="loading-line" id="loadingLine"><span class="spinner"></span><span>POST /api/generate · Calling study engine…</span></div>
      <div class="topic-pills" aria-label="Quick topics">
        <button class="pill" data-topic="Photosynthesis">Photosynthesis</button><button class="pill" data-topic="Newton’s laws of motion">Newton’s laws</button><button class="pill" data-topic="Machine learning basics">Machine learning</button><button class="pill" data-topic="The water cycle">Water cycle</button><button class="pill" data-topic="Big O notation">Big O notation</button>
      </div>
      <div class="section-head"><h2>Your study notes</h2><span id="resultSource" class="api-badge">READY WHEN YOU ARE</span></div>
      <div id="results" class="result-stack"><div class="glass-card empty-state">Your next “aha!” moment starts here. Enter a topic above to generate your first set of study notes.</div></div>
    </div>
    <aside class="right-column">
      <div class="glass-card side-card">
        <div class="profile-row"><div class="avatar" id="avatar">S</div><div><div class="profile-name" id="profileName">Study space</div><div class="profile-email" id="profileEmail">Your learning dashboard</div></div></div>
        <div class="divider"></div>
        <div class="stat-row"><span>AI engine</span><strong id="engineStat">Checking…</strong></div>
        <div class="stat-row"><span>Session</span><strong id="sessionStat">Active</strong></div>
        <div class="stat-row"><span>Notes saved</span><strong id="notesCount">0 this session</strong></div>
      </div>
      <div class="section-head"><h2>Recent topics</h2><span class="tiny-label">LAST 20</span></div>
      <div class="glass-card"><div id="historyList" class="history-list"><div class="empty-state">Your generated topics will appear here.</div></div></div>
      <div class="glass-card side-card" style="margin-top:13px"><div class="tiny-label" style="margin-bottom:11px">STUDY TIP</div><p style="font-size:11px;line-height:1.8;color:#aaa8bd;margin:0">After reading an explanation, close your notes and explain the idea from memory. Retrieval practice helps turn understanding into long-term learning.</p></div>
    </aside>
  </div>
</section>
<footer class="footer"><span>© <span id="year"></span> StudyMate Ultimate · By Riddhi Soni</span><span>soniriddhi1519@gmail.com <span style="color:#a78bfa">·</span> Built for curious minds</span></footer>
</main>
</div>
<div id="toast" class="toast" role="status"></div>
<script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"></script>
<script>
(() => {
  const $ = id => document.getElementById(id);
  let authMode = 'login';
  let noteCount = 0;
  let apiEnabled = false;
  let currentUser = null;
  let toastTimer;
  $('year').textContent = new Date().getFullYear();

  function showToast(message) {
    $('toast').textContent = message;
    $('toast').style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $('toast').style.display = 'none', 3000);
  }
  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  async function jsonFetch(url, options = {}) {
    const response = await fetch(url, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Request failed. Please try again.');
    return data;
  }
  async function checkHealth() {
    try {
      const data = await jsonFetch('/api/health');
      apiEnabled = data.openai === 'Enabled';
      $('apiBadge').innerHTML = '<span class="dot"></span>' + (apiEnabled ? ' REAL AI ON' : ' DEMO MODE');
      $('engineStat').textContent = apiEnabled ? 'GPT-4o-mini' : 'Demo mode';
      $('resultSource').textContent = apiEnabled ? 'REAL OPENAI READY' : 'DEMO MODE READY';
    } catch (_) {
      $('apiBadge').innerHTML = '<span class="dot"></span> API UNAVAILABLE';
      $('engineStat').textContent = 'Unavailable';
    }
  }
  function setAuthMode(mode) {
    authMode = mode;
    const signup = mode === 'signup';
    $('loginTab').classList.toggle('active', !signup);
    $('signupTab').classList.toggle('active', signup);
    $('nameField').classList.toggle('hidden', !signup);
    $('authTitle').textContent = signup ? 'Create your space.' : 'Welcome back.';
    $('authSubtitle').textContent = signup ? 'One account. A more focused way to learn.' : 'Sign in to pick up where your curiosity left off.';
    $('authSubmit').textContent = signup ? 'Create via Real API →' : 'Login via Real API →';
    $('password').autocomplete = signup ? 'new-password' : 'current-password';
    $('authError').style.display = 'none';
  }
  function showAuth() {
    $('authView').style.display = 'flex';
    $('appView').style.display = 'none';
    $('logoutBtn').classList.add('hidden');
    $('topUser').textContent = 'Your personal study space';
  }
  function showApp() {
    $('authView').style.display = 'none';
    $('appView').style.display = 'block';
    $('logoutBtn').classList.remove('hidden');
    currentUser = JSON.parse(localStorage.getItem('sm_user') || 'null');
    $('topUser').textContent = currentUser?.name || 'Study space';
    $('profileName').textContent = currentUser?.name || 'Guest learner';
    $('profileEmail').textContent = currentUser?.email || 'Your learning dashboard';
    $('avatar').textContent = (currentUser?.name || 'S').trim().charAt(0).toUpperCase();
    loadHistory();
  }
  function saveSession(data) {
    localStorage.setItem('sm_token', data.token);
    localStorage.setItem('sm_user', JSON.stringify(data.user));
    currentUser = data.user;
  }
  $('loginTab').addEventListener('click', () => setAuthMode('login'));
  $('signupTab').addEventListener('click', () => setAuthMode('signup'));
  $('authForm').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('authSubmit');
    const payload = { email: $('email').value.trim(), password: $('password').value };
    if (authMode === 'signup') payload.name = $('name').value.trim();
    button.disabled = true;
    button.textContent = authMode === 'signup' ? 'Creating account…' : 'Authenticating…';
    $('authError').style.display = 'none';
    try {
      const data = await jsonFetch(authMode === 'signup' ? '/api/auth/signup' : '/api/auth/login', {
        method: 'POST', body: JSON.stringify(payload)
      });
      saveSession(data);
      if (authMode === 'signup') showToast('Account created. Welcome to StudyMate!');
      showApp();
    } catch (err) {
      $('authError').textContent = err.message;
      $('authError').style.display = 'block';
    } finally {
      button.disabled = false;
      button.textContent = authMode === 'signup' ? 'Create via Real API →' : 'Login via Real API →';
    }
  });
  $('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem('sm_token');
    localStorage.removeItem('sm_user');
    currentUser = null;
    showAuth();
    showToast('You have been logged out.');
  });

  function resultCard(title, icon, body) {
    return '<article class="glass-card result-card"><h3 class="result-title"><span class="mini-icon">' + icon + '</span>' + title + '</h3>' + body + '</article>';
  }
  function renderResult(result) {
    const examples = Array.isArray(result.examples) ? result.examples : [];
    const qa = Array.isArray(result.qa) ? result.qa : [];
    let html = resultCard('The core idea', '✳', '<p>' + escapeHTML(result.explanation) + '</p>');
    html += '<div class="result-grid">';
    html += resultCard('A useful analogy', '↗', '<p>' + escapeHTML(result.analogy || 'Connect the concept to something familiar, then test that connection with an example.') + '</p>');
    html += resultCard('Memory trick', '⌁', '<p>' + escapeHTML(result.memoryTrick || 'Explain the idea in your own words, then retrieve it from memory.') + '</p>');
    html += '</div>';
    html += resultCard('Examples to make it stick', '▤', '<ul>' + examples.map(item => '<li>' + escapeHTML(item) + '</li>').join('') + '</ul>');
    if (qa.length) html += resultCard('Quick self-check', '?', '<ul>' + qa.map(item => '<li><strong style="color:#e9d5ff">' + escapeHTML(item.question || 'Question') + '</strong><br>' + escapeHTML(item.answer || '') + '</li>').join('') + '</ul>');
    $('results').innerHTML = html;
    $('resultSource').textContent = result.source || (apiEnabled ? 'REAL OPENAI' : 'DEMO MODE');
  }
  async function generate(topic) {
    const cleanTopic = String(topic || '').trim();
    if (!cleanTopic) return;
    $('topicInput').value = cleanTopic;
    $('generateBtn').disabled = true;
    $('generateBtn').textContent = 'Generating…';
    $('loadingLine').style.display = 'flex';
    $('results').innerHTML = '<div class="glass-card empty-state">Building your explanation, analogy, examples, and memory trick…</div>';
    try {
      const data = await jsonFetch('/api/generate', {
        method: 'POST',
        headers: localStorage.getItem('sm_token') ? { Authorization: 'Bearer ' + localStorage.getItem('sm_token') } : {},
        body: JSON.stringify({ topic: cleanTopic, token: localStorage.getItem('sm_token') || undefined })
      });
      renderResult(data.result);
      noteCount++;
      $('notesCount').textContent = noteCount + ' this session';
      await loadHistory();
    } catch (err) {
      $('results').innerHTML = '<div class="glass-card empty-state">' + escapeHTML(err.message) + '</div>';
    } finally {
      $('generateBtn').disabled = false;
      $('generateBtn').textContent = 'Generate notes ↗';
      $('loadingLine').style.display = 'none';
    }
  }
  $('generateForm').addEventListener('submit', event => {
    event.preventDefault();
    generate($('topicInput').value);
  });
  document.querySelectorAll('[data-topic]').forEach(button => button.addEventListener('click', () => generate(button.dataset.topic)));
  async function loadHistory() {
    try {
      const headers = localStorage.getItem('sm_token') ? { Authorization: 'Bearer ' + localStorage.getItem('sm_token') } : {};
      const data = await jsonFetch('/api/history', { headers });
      const history = data.history || [];
      $('historyList').innerHTML = history.length ? history.map(item =>
        '<div class="history-item" data-history-topic="' + escapeHTML(item.topic) + '"><strong>' + escapeHTML(item.topic) + '</strong><span>' + escapeHTML(item.source) + ' · ' + escapeHTML(item.createdAt || '') + '</span></div>'
      ).join('') : '<div class="empty-state">No topics yet. Generate your first notes to start a history.</div>';
      $('historyList').querySelectorAll('[data-history-topic]').forEach(item => item.addEventListener('click', () => generate(item.dataset.historyTopic)));
    } catch (_) {
      $('historyList').innerHTML = '<div class="empty-state">History is temporarily unavailable.</div>';
    }
  }

  // Subtle 3D particle field: 80 points, purple, slow rotation.
  function initScene() {
    if (!window.THREE) return;
    try {
      const canvas = $('scene');
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 100);
      camera.position.z = 15;
      const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(window.innerWidth, window.innerHeight);
      const positions = new Float32Array(80 * 3);
      for (let i = 0; i < 80; i++) {
        positions[i * 3] = (Math.random() - .5) * 35;
        positions[i * 3 + 1] = (Math.random() - .5) * 22;
        positions[i * 3 + 2] = (Math.random() - .5) * 18;
      }
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const material = new THREE.PointsMaterial({ color: 0xa855f7, size: .045, transparent: true, opacity: .62, sizeAttenuation: true });
      const points = new THREE.Points(geometry, material);
      scene.add(points);
      let raf;
      const animate = () => {
        points.rotation.y += .0005;
        points.rotation.x += .00012;
        renderer.render(scene, camera);
        raf = requestAnimationFrame(animate);
      };
      animate();
      window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
      });
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) cancelAnimationFrame(raf);
        else animate();
      });
    } catch (err) {
      console.warn('3D background unavailable:', err.message);
    }
  }
  // Gentle mouse tilt on desktop only.
  const panel = $('searchPanel');
  panel.addEventListener('mousemove', event => {
    if (window.innerWidth < 900) return;
    const rect = panel.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - .5;
    const y = (event.clientY - rect.top) / rect.height - .5;
    panel.style.transform = 'perspective(900px) rotateX(' + (-y * 1.6) + 'deg) rotateY(' + (x * 1.8) + 'deg)';
  });
  panel.addEventListener('mouseleave', () => panel.style.transform = 'perspective(900px) rotateX(0) rotateY(0)');

  checkHealth();
  initScene();
  const token = localStorage.getItem('sm_token');
  const savedUser = localStorage.getItem('sm_user');
  if (token && savedUser) {
    try { currentUser = JSON.parse(savedUser); showApp(); }
    catch (_) { localStorage.removeItem('sm_token'); localStorage.removeItem('sm_user'); showAuth(); }
  } else {
    showAuth();
  }
})();
</script>
</body>
</html>`;

app.get('/', (_req, res) => {
  res.type('html').send(FRONTEND_HTML);
});

app.get('/api', (_req, res) => res.json({
  name: 'StudyMate Ultimate',
  version: VERSION,
  author: 'Riddhi Soni',
  docs: ['/api/health', '/api/auth/signup', '/api/auth/login', '/api/generate', '/api/history']
}));

app.use((err, _req, res, _next) => {
  console.error('Unhandled request error:', err.message);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`StudyMate Ultimate running at http://localhost:${PORT}`);
    console.log(`AI mode: ${process.env.OPENAI_API_KEY ? 'OpenAI GPT-4o-mini' : 'Demo Mode'}`);
    if (JWT_SECRET === 'change-this-development-secret-before-deploying') {
      console.warn('WARNING: Set JWT_SECRET to a long random secret before deploying.');
    }
  });
}

module.exports = app;
