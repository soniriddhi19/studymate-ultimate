# StudyMate Ultimate

A single-file Node.js + Express app with embedded HTML/CSS/JS, Three.js particle background, JWT auth, bcrypt password hashing, SQLite, and optional OpenAI GPT-4o-mini integration.

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000

The default login form is prefilled with `soniriddhi1519@gmail.com` / `123456`, but this is **not a pre-created account**. Use Create account once to register that email/password, or log in with credentials you have already registered.

## Environment variables

```bash
# Set a long, unique secret in production
JWT_SECRET=replace-with-a-long-random-secret
OPENAI_API_KEY=your-openai-api-key
# Optional; defaults to ./studymate.sqlite. Use :memory: for ephemeral tests.
DB_PATH=./studymate.sqlite
PORT=3000
```

Without `OPENAI_API_KEY`, the app generates clearly labelled demo study notes. If OpenAI is configured but unavailable, the request falls back to demo content and labels it accordingly.

## API

- `GET /api/health`
- `POST /api/auth/signup` — `{ "name": "...", "email": "...", "password": "..." }`
- `POST /api/auth/login` — `{ "email": "...", "password": "..." }`
- `POST /api/generate` — `{ "topic": "...", "token": "optional JWT" }`
- `GET /api/history` — last 20 generations for the signed-in user, or anonymous generations

## Deployment note

`vercel.json` is included. Vercel serverless functions do not provide durable local SQLite storage: the file system is ephemeral and instances may not share data. For durable production auth/history on Vercel, replace SQLite with a hosted persistent database (for example, a managed Postgres service). Set `JWT_SECRET` and `OPENAI_API_KEY` in Vercel project environment variables. Never commit real secrets to GitHub.
